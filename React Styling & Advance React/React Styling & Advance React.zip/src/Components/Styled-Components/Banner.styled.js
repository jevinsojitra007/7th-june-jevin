

import styled from "styled-components";

export const ImgContainer=styled.div`

    & > img{
        width: 450px;
    }
`