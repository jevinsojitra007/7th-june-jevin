

export const NavLink = [
    {
        id:0,
        name: 'Home',
    },
    {
        id:1,
        name: 'Store',
    },
    {
        id:2,
        name: 'Promo',
    },
    {
        id:3,
        name: 'Product',
    },
    {
        id:4,
        name: 'About',
    },
    {
        id:5,
        name: 'Contact',
    }
    
]